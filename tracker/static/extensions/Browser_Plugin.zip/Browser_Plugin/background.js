let currentTab = null;
let startTime = null;

chrome.tabs.onActivated.addListener(async (activeInfo) => {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    logTimeSpent();
    currentTab = tab;
    startTime = new Date().getTime();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.active && changeInfo.status === "complete") {
        logTimeSpent();
        currentTab = tab;
        startTime = new Date().getTime();
    }
});

chrome.windows.onFocusChanged.addListener((windowId) => {
    logTimeSpent();
    currentTab = null;
    startTime = null;
});

function logTimeSpent() {
    if (currentTab && startTime) {
        const endTime = new Date().getTime();
        const timeSpent = Math.round((endTime - startTime) / 1000); 
        const url = currentTab.url;
        let query = '';

        try {
            const urlObj = new URL(url);
            const host = urlObj.hostname;

            const searchParams = urlObj.searchParams;

            if (host.includes("google.") && searchParams.has("q")) {
                query = searchParams.get("q");
            } else if (host.includes("bing.") && searchParams.has("q")) {
                query = searchParams.get("q");
            } else if (host.includes("duckduckgo.") && searchParams.has("q")) {
                query = searchParams.get("q");
            } else if (host.includes("yahoo.") && searchParams.has("p")) {
                query = searchParams.get("p");
            } else if (host.includes("youtube.") && searchParams.has("search_query")) {
                query = searchParams.get("search_query");
            }
        } catch (err) {
            console.error("Query extraction error:", err);
        }

        const data = {
            url: url,
            query: query || '',
            time_spent: timeSpent
        };

        fetch("http://127.0.0.1:8000/api/track/", {
            method: "POST",
            body: JSON.stringify(data),
            headers: { "Content-Type": "application/json" }
        });

        console.log("📦 Sent:", data);
    }
}
